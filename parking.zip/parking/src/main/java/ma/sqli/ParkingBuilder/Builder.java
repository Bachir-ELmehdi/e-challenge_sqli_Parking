package ma.sqli.ParkingBuilder;

import ma.sqli.parking.Parking;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> parking
 * Package =====> ma.sqli.ParkingBuilder
 * Date    =====> 18 nov. 2019 
 */
public interface Builder {
	
	public ParkingBuilder withSquareSize(int squareSize);
	public ParkingBuilder withPedestrianExit(int index);
	public ParkingBuilder withDisabledBay(int index);
	public Parking build();

}
