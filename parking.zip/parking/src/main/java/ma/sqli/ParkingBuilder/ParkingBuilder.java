package ma.sqli.ParkingBuilder;

import ma.sqli.parking.Parking;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> parking
 * Package =====> ma.sqli.ParkingBuilder
 * Date    =====> 18 nov. 2019 
 */
public class ParkingBuilder  implements Builder{
    
    static	Parking parking = new Parking();
	@Override
	public ParkingBuilder withSquareSize(int squareSize) {
		// TODO Auto-generated method stub
		parking.initialise(squareSize * squareSize);
		return this;
	}

	@Override
	public ParkingBuilder withPedestrianExit(int firstupedestrianuexituindex) {
		// TODO Auto-generated method stub
		parking.addPedestExit(firstupedestrianuexituindex);
		return this;
	}

	@Override
	public ParkingBuilder withDisabledBay(int index) {
		// TODO Auto-generated method stub
		parking.addDiabledSlot(index);
		return this;
	}

	@Override
	public Parking build() {
		// TODO Auto-generated method stub
		return parking;
	}

}
