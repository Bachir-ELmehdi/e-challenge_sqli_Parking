package ma.sqli.Mitier;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> parking
 * Package =====> ma.sqli.Mitier
 * Date    =====> 18 nov. 2019 
 */
public class ImplMitier implements IMitier {

	@Override
	public int parKCar(char[] slots, char car) {
		// TODO Auto-generated method stub
		int index;
		if(car =='D') {
		    index =  getDisabledPlace(slots);
		    if(index != -1)
			slots[index] = 'D';
		}
		else {
			index = getPlace(slots);
			slots[index] = car;
		}
		return index;
		
	}

	@Override
	public boolean unparkCar(char[] slots, int index) {
		// TODO Auto-generated method stub
		boolean test = (slots[index] !='U' ==true && slots[index] != '=');
		if(test) slots[index] = 'U';	
		return test;
	}

	@Override
	public int getPlace(char[] slots) {
		// TODO Auto-generated method stub
	   int sui =getPedestExit(slots)+1;
	   int pre = getPedestExit(slots)-1;
	   while(pre>=0 && sui<= slots.length ) {
	   if(slots[pre] == 'U')return pre;
	   if(slots[sui] == 'U' )return sui;
	   pre--;sui++;}
		return -1;
	}

	@Override
	public int getDisabledPlace(char[] slots) {
		// TODO Auto-generated method stub
		int returnindex =-1;
		int space = Integer.MAX_VALUE;
		int index = getPedestExit(slots);
		for(int i=0; i<slots.length ; i++) {
			if(index-i ==0 ) index = getPedestExitd(slots);
			if(slots[i] == '@' && Math.abs(index-i) < space) {
				returnindex = i;
				space = Math.abs(index-i);
			}
		}
		return returnindex;
	}
	
	public int getPedestExitd(char [] slots) {
		int index = 0;
		for(int i=0; i<slots.length; i++) {
			if(slots[i] == '=')index = i;
		}
		return index;
	}

	@Override
	public int getPedestExit(char[] slots) {
		// TODO Auto-generated method stub
		for(int i=0; i<slots.length; i++) {
			if(slots[i] == '=')return i;
		}
		return -1;
	}
	
	

}
