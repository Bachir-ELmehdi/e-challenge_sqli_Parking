package ma.sqli.Mitier;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> parking
 * Package =====> ma.sqli.Mitier
 * Date    =====> 18 nov. 2019 
 */
public interface IMitier {
	public int parKCar(char[] slots,char c);
    public boolean unparkCar(char[] slots,int index);
    public int getPlace(char[] slots);
    public int getDisabledPlace(char[] slots);
    public int getPedestExit(char[] slots);
    

}
