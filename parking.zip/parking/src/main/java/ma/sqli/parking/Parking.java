package ma.sqli.parking;
import java.security.cert.CertPathBuilder;
import java.util.Arrays;
import ma.sqli.Mitier.*;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> parking
 * Package =====> ma.sqli.parking
 * Date    =====> 18 nov. 2019 
 */
public class Parking {
	public char[]slots;
	public int rowSize;
	public ImplMitier mitier = new ImplMitier();
	public Parking() {
		
	}
	public void initialise(int squareSize) {
		rowSize = (int) Math.sqrt(squareSize);
		slots = new char[squareSize];

    	Arrays.fill(slots, 'U');
		
	}
	
	public void addPedestExit(int pedestexit) {
		slots[pedestexit] = '=';
	}
	public void addDiabledSlot(int disable) {
		slots[disable] = '@';
	}
	
	public int parkCar(char c) {
		return  mitier.parKCar(slots, c);
		
	}
	
	
	public int  getAvailableBays() {
		int count =0;
		for(int i=0;i<slots.length ;i++)
		{
			if(slots[i]=='U' || slots[i] == '@')count++;		
		}
		return count;
	}
	
	public boolean unparkCar(int index) {
		return mitier.unparkCar(slots, index);
	}
	public String toString() {
		StringBuilder  sb = new StringBuilder();
		int i=0;
		for(char c: slots) {
			i++;			
			sb.append(c);
			if(i%rowSize ==0) sb.append("\\n");	
		}	
		sb.delete(sb.length()-2, sb.length());
		return sb.toString();
	}
	

}
